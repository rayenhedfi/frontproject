import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { Routes, RouterModule } from "@angular/router";
import { NgApexchartsModule } from "ng-apexcharts";
import { DashboardComponent2 } from "./dashboard2.component";
import { NgbPopoverModule } from '@ng-bootstrap/ng-bootstrap';


const routes: Routes = [
  {
    path: "",
    data: {
      title: "Dashboard2",
      urls: [{ title: "Dashboard2", url: "/dashboard2" }, { title: "Dashboard2" }],
    },
    component: DashboardComponent2,
  },
];

@NgModule({
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    RouterModule.forChild(routes),
    NgApexchartsModule,
    NgbPopoverModule
  ],
  declarations: [
    DashboardComponent2,
 
  ],
})
export class DashboardModule2 {}
