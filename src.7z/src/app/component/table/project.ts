export class Project {
    id: any;
    name: any;
    description: any;
    visibility: any;
    token: any;
    gitlabProjectId: any;
   // branches: Branche;
}