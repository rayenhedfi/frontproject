export class ImportRequest {
    username: string='';
    password: string='';
    svnUrl: string= '';
  }
  