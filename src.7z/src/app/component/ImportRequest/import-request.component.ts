import { Component, Output, EventEmitter,Input } from '@angular/core';
import { ImportRequest } from './import-request.model';
import { ImportRequestService } from './import-request.service';


@Component({
  selector: 'app-import-request',
  templateUrl: './import-request.component.html',
  styleUrls: ['./import-request.component.scss']
})
export class ImportRequestComponent {
    importRequest: ImportRequest = new ImportRequest();

  /*importRequest: ImportRequest = {
    username: '',
    password: '',
    svnUrl: ''
  };*/

  @Output() requestSubmitted = new EventEmitter<ImportRequest>();

  constructor(private importRequestService: ImportRequestService) {}

  submitRequest() {
    if (this.isValidRequest()) {
      this.importRequestService.sendImportRequest(this.importRequest).subscribe(
        response => {
          console.log('Requête importée avec succès.', response);
          this.requestSubmitted.emit(this.importRequest);
        },
        error => {
          console.error('Une erreur s\'est produite lors de l\'importation de la requête.', error);
        }
      );
    }
  }

  private isValidRequest(): boolean {
    return (
      this.importRequest.username !== '' &&
      this.importRequest.password !== '' &&
      this.importRequest.svnUrl !== ''
    );
  }
}
