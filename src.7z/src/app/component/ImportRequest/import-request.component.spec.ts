import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ImportRequest } from './import-request.model';

describe('FolderComponent', () => {
  let component: ImportRequest;
  let fixture: ComponentFixture<ImportRequest>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImportRequest ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImportRequest);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
