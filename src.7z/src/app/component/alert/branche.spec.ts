import { Branche } from "./branche";

describe('Branche', () => {

    it('should create an instance', () => {
  
      expect(new Branche()).toBeTruthy();
  
    });
  
  });