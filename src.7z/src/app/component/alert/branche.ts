export class Branche{
brancheid:any;
brancheNom:any;
brancheRef:any;


}