import { TestBed } from '@angular/core/testing';

import { DemandemigrationService } from './demandemigration.service';

describe('ProjectService', () => {
  let service: DemandemigrationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DemandemigrationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
