import { Component, OnInit } from '@angular/core';
import { DemandemigrationService } from './demandemigration.service';
import { Demandemigration } from './demandemigration';
import {ModalDismissReasons, NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {Router} from "@angular/router";
import {FormGroup} from "@angular/forms";
@Component({
  templateUrl: 'card.component.html',
  styleUrls: ['./demandemigration.component.scss']

})
export class CardsComponent implements OnInit{

listDemandemigration:any;
demandemigration!:any;
form: boolean = false;
closeResult!: string;

constructor(private demandemigrationservice:DemandemigrationService, private router: Router,private modalService: NgbModal,){}
ngOnInit(): void {
  this.getDemandeMigration()
  this.demandemigration = {

  id: null,
  nom_projet: null,
  plateforme_migration: null,
  type_migration:  null,
  status:  null,
  urlSvn: null,
  urlGit: null,
  Token: null,
  SvnUsername: null,
  SvnPassword: null,
  }
}

getDemandeMigration(){
  this.demandemigrationservice.getAllDemandemigration().subscribe(res=>this.listDemandemigration=res);
}

addMigration(m:any){
  this.demandemigrationservice.savedemandemigratoin(m).subscribe(()=>{
    this.getDemandeMigration();
  })
}
closeForm(){

}
cancel(){
  this.form = false;
}
open(content: any) {
  this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  });
}
private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return  `with: ${reason}`;
  }
}
}


