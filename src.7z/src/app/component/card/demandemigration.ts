export class Demandemigration{
id:any;
nom_projet:any;
plateforme_migration:any;
type_migration:any;
status:any;
urlSvn:any;
urlGit:any;
Token:any;
SvnUsername:any;
SvnPassword:any;
}