import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Demandemigration } from './demandemigration';
import { environment } from './../../../environments/environment';
import { Branche } from '../alert/branche';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DemandemigrationService  {
  private api_url = environment.api_url + 'mig';
  constructor(private http: HttpClient) { }
  

  public getAllDemandemigration() {
    return this.http.get(this.api_url + '/retrieve-all-migration')
  }

  public savedemandemigratoin(demandemigration: Demandemigration): Observable<Demandemigration[]>{
     return this.http.post<Demandemigration[]>(`${this.api_url}/add-migration`, demandemigration);
  }
  /*public savedemandemigratoin(demandemigration:DemandemigrationService ) {
    return this.http.post(this.api_url + '/add-migration', demandemigration)
  }*/
  /*public affecterbrancheToProject(branche: Branche, id: Project) {
    return this.http.put(this.api_url + '/assignbrancheToProject/' +id, branche)
  }
*/


}
export { Demandemigration };

