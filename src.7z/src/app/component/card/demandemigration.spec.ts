import { Demandemigration } from "./demandemigration";

describe('Demandemigration', () => {

    it('should create an instance', () => {
  
      expect(new Demandemigration()).toBeTruthy();
  
    });
  
  });